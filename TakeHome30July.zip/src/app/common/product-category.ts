export class ProductCategory {
    constructor(
       public categoryid: number,
       public categoryname: string,
    ){}
}